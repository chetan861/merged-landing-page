import ConsultationForm from "@/components/ConsultationForm";
import { CheckCircle2, Users, Heart, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * Praan Health Consultation Landing Page
 * 
 * Brand Guidelines Implementation:
 * - Primary Color: Praan Orange (#FD7118) - Energy, Progress, Warmth
 * - Secondary Color: Healing Blue (#303880) - Trust, Stability, Guidance
 * - Accent Color: Calm Teal (#63C5B8) - Balance and healing
 * - Background: Care Linen (#F6E9E0) - Warm, approachable
 * - Text: Soft Charcoal (#1A1A1A) - Professional, readable
 * - Primary Font: Aeonik (headings)
 * - Secondary Font: Archivo (body copy)
 */

export default function Home() {
  const testimonials = [
    {
      name: "Siddharth Krishna's Mom",
      location: "Bangalore, India",
      quote:
        "Two years after cancer surgery, my son enrolled me in Praan's program. In just two months, I feel healthier, stronger, and more energetic.",
      highlight: "Blood sugar dropped, shoulder pain almost gone",
      color: "from-praan-orange to-orange-300",
    },
    {
      name: "Rajesh Patel's Father",
      location: "Mumbai, India",
      quote:
        "After struggling with diabetes for years, Praan's personalized approach helped me reverse my condition. The strength training is incredible.",
      highlight: "Reversed early signs of diabetes",
      color: "from-praan-blue to-blue-300",
    },
    {
      name: "Anjali Sharma's Mother",
      location: "Delhi, India",
      quote:
        "My mother was losing confidence, but Praan gave her back her strength and independence. She's thriving now!",
      highlight: "Regained strength and independence",
      color: "from-praan-orange to-orange-300",
    },
  ];

  const benefits = [
    {
      icon: Heart,
      title: "Personalized Care",
      description: "Science-backed programs tailored to your parent's specific health needs",
    },
    {
      icon: Users,
      title: "Family-Focused",
      description: "Designed for children who care from a distance and want to stay involved",
    },
    {
      icon: TrendingUp,
      title: "Real Results",
      description: "Proven outcomes: reversed conditions, increased strength, better quality of life",
    },
    {
      icon: CheckCircle2,
      title: "Expert Team",
      description: "Doctor-led care with nutrition, strength training, and emotional support",
    },
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#F6E9E0" }}>
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b" style={{ borderColor: "#e8e4df" }}>
        <div className="container flex items-center justify-between py-4">
          <div className="praan-logo">
            <div className="praan-logo-icon">P</div>
            <span className="font-bold text-lg" style={{ color: "#FD7118", fontFamily: "'Aeonik', sans-serif" }}>Praan Health</span>
          </div>
          <Button
            onClick={() => document.getElementById("consultation-form")?.scrollIntoView({ behavior: "smooth" })}
            className="praan-btn-primary text-sm"
          >
            Book Now
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 py-16 lg:py-24 items-center">
          {/* Left Content */}
          <div className="space-y-6 lg:space-y-8 order-2 lg:order-1">
            <div className="space-y-4">
              <h1 className="praan-headline">
                Your Parents' Health
                <span style={{ color: "#FD7118" }}> Deserves Better Care</span>
              </h1>
              <p className="praan-body text-lg">
                India's first family-focused chronic care platform. Where children guide, monitor, and heal from a distance. Where parents thrive, strengthen, and glow.
              </p>
            </div>

            {/* Key Stats */}
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="space-y-1">
                <p className="text-3xl font-bold" style={{ color: "#FD7118", fontFamily: "'Aeonik', sans-serif" }}>500K+</p>
                <p className="text-sm" style={{ color: "#666666" }}>Families Transformed</p>
              </div>
              <div className="space-y-1">
                <p className="text-3xl font-bold" style={{ color: "#303880", fontFamily: "'Aeonik', sans-serif" }}>95%</p>
                <p className="text-sm" style={{ color: "#666666" }}>Satisfaction Rate</p>
              </div>
            </div>

            <div className="space-y-4 pt-4">
              <Button
                onClick={() => document.getElementById("consultation-form")?.scrollIntoView({ behavior: "smooth" })}
                className="praan-btn-primary text-sm"
              >
                Book Free Consultation →
              </Button>
            </div>
          </div>

          {/* Right - Hero Image */}
          <div className="order-1 lg:order-2">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl" style={{ backgroundColor: "#303880" }}>
              <div className="aspect-square flex items-center justify-center text-white text-center p-8">
                <div>
                  <div className="text-6xl mb-4">👨‍👩‍👧‍👦</div>
                  <p className="text-xl font-bold" style={{ fontFamily: "'Aeonik', sans-serif" }}>Family Care</p>
                  <p className="text-sm mt-2 opacity-90">Trusted by 500,000+ families across India</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container py-16 lg:py-24">
        <div className="space-y-12">
          <div className="text-center space-y-4 max-w-2xl mx-auto">
            <h2 className="praan-subheading">
              Why Choose Praan Health?
            </h2>
            <p className="praan-body text-lg">
              Science-backed, family-centered care that brings real visibility, control, and results.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, idx) => {
              const Icon = benefit.icon;
              const colors = idx % 2 === 0 ? { bg: "#FD7118", text: "#FD7118" } : { bg: "#303880", text: "#303880" };
              
              return (
                <div key={idx} className="group p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-300 bg-white">
                  <div className="p-3 rounded-lg mb-4 inline-block" style={{ backgroundColor: `${colors.bg}20` }}>
                    <Icon className="w-6 h-6" style={{ color: colors.text }} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold" style={{ color: "#1A1A1A", fontFamily: "'Aeonik', sans-serif" }}>
                      {benefit.title}
                    </h3>
                    <p className="praan-body text-sm">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Consultation Form Section */}
      <section className="container py-16 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">
          {/* Left - Form */}
          <div className="order-2 lg:order-1">
            <div className="bg-white rounded-2xl p-8 lg:p-10 border border-gray-100 shadow-lg">
              <div className="space-y-2 mb-8">
                <h2 className="praan-subheading">
                  Book Your Free Consultation
                </h2>
                <p className="praan-body">
                  Share your details and our experts will guide you through personalized care options.
                </p>
              </div>

              <ConsultationForm />

              <p className="text-xs mt-6" style={{ color: "#666666" }}>
                We respect your privacy. Your information will only be used to schedule your consultation.
              </p>
            </div>
          </div>

          {/* Right - Benefits List */}
          <div className="order-1 lg:order-2 space-y-6">
            {[
              {
                title: "Personalized Assessment",
                description: "Our experts will understand your parent's unique health needs",
                color: "#FD7118"
              },
              {
                title: "Customized Care Plan",
                description: "Get a tailored program combining medicine, nutrition, and fitness",
                color: "#303880"
              },
              {
                title: "Ongoing Support",
                description: "Regular check-ins and adjustments to ensure continuous progress",
                color: "#63C5B8"
              },
            ].map((item, idx) => (
              <div key={idx} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg" style={{ backgroundColor: `${item.color}20` }}>
                    <CheckCircle2 className="h-6 w-6" style={{ color: item.color }} />
                  </div>
                </div>
                <div>
                  <h3 className="font-bold" style={{ color: "#1A1A1A", fontFamily: "'Aeonik', sans-serif" }}>
                    {item.title}
                  </h3>
                  <p className="text-sm praan-body mt-1">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="container py-16 lg:py-24">
        <div className="space-y-12">
          <div className="text-center space-y-4 max-w-2xl mx-auto">
            <h2 className="praan-subheading">
              Real Families, Real Transformations
            </h2>
            <p className="praan-body text-lg">
              Hear from families who've experienced the Praan difference
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300 border border-gray-100">
                <p className="praan-body mb-4 italic">"{testimonial.quote}"</p>
                
                <div className="flex items-center gap-2 mb-4 pb-4 border-b" style={{ borderColor: "#e8e4df" }}>
                  <span style={{ color: "#FD7118" }}>✓</span>
                  <p className="text-sm font-semibold" style={{ color: "#1A1A1A" }}>
                    {testimonial.highlight}
                  </p>
                </div>

                <div>
                  <p className="font-bold" style={{ color: "#1A1A1A", fontFamily: "'Aeonik', sans-serif" }}>
                    {testimonial.name}
                  </p>
                  <p className="text-sm" style={{ color: "#666666" }}>
                    {testimonial.location}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-16 lg:py-24" style={{ backgroundColor: "#303880" }}>
        <div className="container text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-3xl lg:text-4xl font-bold text-white" style={{ fontFamily: "'Aeonik', sans-serif" }}>
              Ready to Transform Your Parent's Health?
            </h2>
            <p className="text-lg text-white/90 max-w-2xl mx-auto" style={{ fontFamily: "'Archivo', sans-serif" }}>
              Join 500,000+ families who are redefining parent care with Praan Health
            </p>
          </div>

          <Button
            onClick={() => document.getElementById("consultation-form")?.scrollIntoView({ behavior: "smooth" })}
            className="praan-btn-primary text-sm"
          >
            Book Your Free Consultation Today
          </Button>

          <p className="text-sm text-white/80" style={{ fontFamily: "'Archivo', sans-serif" }}>
            No commitment required. Just a conversation with our experts.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t" style={{ borderColor: "#e8e4df" }}>
        <div className="container py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="praan-logo mb-4">
                <div className="praan-logo-icon">P</div>
                <span className="font-bold" style={{ color: "#FD7118", fontFamily: "'Aeonik', sans-serif" }}>Praan Health</span>
              </div>
              <p className="text-sm praan-body">
                India's first family-focused chronic care platform
              </p>
            </div>

            <div>
              <h4 className="font-bold text-sm mb-4" style={{ color: "#1A1A1A", fontFamily: "'Aeonik', sans-serif" }}>Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="praan-body hover:text-praan-orange transition">How Praan Works</a></li>
                <li><a href="#" className="praan-body hover:text-praan-orange transition">About Us</a></li>
                <li><a href="#" className="praan-body hover:text-praan-orange transition">Contact</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-sm mb-4" style={{ color: "#1A1A1A", fontFamily: "'Aeonik', sans-serif" }}>Follow Us</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="praan-body hover:text-praan-orange transition">Instagram</a></li>
                <li><a href="#" className="praan-body hover:text-praan-orange transition">LinkedIn</a></li>
                <li><a href="#" className="praan-body hover:text-praan-orange transition">Twitter</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-sm mb-4" style={{ color: "#1A1A1A", fontFamily: "'Aeonik', sans-serif" }}>Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="praan-body hover:text-praan-orange transition">Privacy Policy</a></li>
                <li><a href="#" className="praan-body hover:text-praan-orange transition">Terms of Service</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t pt-8" style={{ borderColor: "#e8e4df" }}>
            <p className="text-center text-sm" style={{ color: "#666666" }}>
              © 2026 Praan Health. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
