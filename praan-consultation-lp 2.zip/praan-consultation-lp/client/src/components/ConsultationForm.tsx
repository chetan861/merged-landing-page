import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowRight, Loader2 } from "lucide-react";

// Praan Health Brand Colors
const BRAND_COLORS = {
  orange: "#FD7118",
  blue: "#303880",
  teal: "#63C5B8",
  charcoal: "#1A1A1A",
  linen: "#F6E9E0",
  border: "#e8e4df",
};

const FONTS = {
  aeonik: "'Aeonik', sans-serif",
  archivo: "'Archivo', sans-serif",
};

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
}

export default function ConsultationForm() {
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    if (
      !formData.firstName.trim() ||
      !formData.lastName.trim() ||
      !formData.email.trim() ||
      !formData.phone.trim()
    ) {
      toast.error("Please fill in all fields");
      return;
    }

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    // Validate phone
    const phoneRegex = /^[\d\s\-\+\(\)]{10,}$/;
    if (!phoneRegex.test(formData.phone)) {
      toast.error("Please enter a valid phone number");
      return;
    }

    setIsLoading(true);

    try {
      // Prepare data to send to Cal.id
      const calIdUrl = new URL("https://cal.id/advisors/consultation");
      
      // Add form data as URL parameters
      calIdUrl.searchParams.append("name", `${formData.firstName} ${formData.lastName}`);
      calIdUrl.searchParams.append("email", formData.email);
      calIdUrl.searchParams.append("phone", formData.phone);

      // Show success message
      toast.success("Great! Redirecting to booking...");
      
      // Mark form as submitted
      setIsSubmitted(true);

      // Redirect to Cal.id after a short delay
      setTimeout(() => {
        window.location.href = calIdUrl.toString();
      }, 1000);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Something went wrong. Please try again.");
      setIsLoading(false);
    }
  };

  if (isSubmitted && isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin mb-4" style={{ color: BRAND_COLORS.orange }} />
        <p className="font-medium" style={{ color: "#666666", fontFamily: FONTS.archivo }}>
          Preparing your consultation...
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* First Name */}
      <div className="space-y-2">
        <Label
          htmlFor="firstName"
          className="text-sm font-semibold"
          style={{ color: BRAND_COLORS.charcoal, fontFamily: FONTS.aeonik }}
        >
          First Name
        </Label>
        <Input
          id="firstName"
          name="firstName"
          type="text"
          placeholder="Enter your first name"
          value={formData.firstName}
          onChange={handleChange}
          className="border-2 rounded-lg py-3 px-4 transition-colors duration-200"
          style={{ 
            borderColor: BRAND_COLORS.border,
            fontFamily: FONTS.archivo
          }}
          onFocus={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.orange}
          onBlur={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.border}
          disabled={isLoading}
        />
      </div>

      {/* Last Name */}
      <div className="space-y-2">
        <Label
          htmlFor="lastName"
          className="text-sm font-semibold"
          style={{ color: BRAND_COLORS.charcoal, fontFamily: FONTS.aeonik }}
        >
          Last Name
        </Label>
        <Input
          id="lastName"
          name="lastName"
          type="text"
          placeholder="Enter your last name"
          value={formData.lastName}
          onChange={handleChange}
          className="border-2 rounded-lg py-3 px-4 transition-colors duration-200"
          style={{ 
            borderColor: BRAND_COLORS.border,
            fontFamily: FONTS.archivo
          }}
          onFocus={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.orange}
          onBlur={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.border}
          disabled={isLoading}
        />
      </div>

      {/* Email */}
      <div className="space-y-2">
        <Label
          htmlFor="email"
          className="text-sm font-semibold"
          style={{ color: BRAND_COLORS.charcoal, fontFamily: FONTS.aeonik }}
        >
          Email Address
        </Label>
        <Input
          id="email"
          name="email"
          type="email"
          placeholder="your.email@example.com"
          value={formData.email}
          onChange={handleChange}
          className="border-2 rounded-lg py-3 px-4 transition-colors duration-200"
          style={{ 
            borderColor: BRAND_COLORS.border,
            fontFamily: FONTS.archivo
          }}
          onFocus={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.orange}
          onBlur={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.border}
          disabled={isLoading}
        />
      </div>

      {/* Phone */}
      <div className="space-y-2">
        <Label
          htmlFor="phone"
          className="text-sm font-semibold"
          style={{ color: BRAND_COLORS.charcoal, fontFamily: FONTS.aeonik }}
        >
          Phone Number
        </Label>
        <Input
          id="phone"
          name="phone"
          type="tel"
          placeholder="+91 98765 43210"
          value={formData.phone}
          onChange={handleChange}
          className="border-2 rounded-lg py-3 px-4 transition-colors duration-200"
          style={{ 
            borderColor: BRAND_COLORS.border,
            fontFamily: FONTS.archivo
          }}
          onFocus={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.orange}
          onBlur={(e) => e.currentTarget.style.borderColor = BRAND_COLORS.border}
          disabled={isLoading}
        />
      </div>

      {/* Submit Button */}
      <Button
        type="submit"
        disabled={isLoading}
        className="w-full praan-btn-primary text-base font-semibold flex items-center justify-center gap-2 group"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            Book Your Consultation
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </>
        )}
      </Button>

      {/* Privacy Notice */}
      <p className="text-xs text-center" style={{ color: "#666666", fontFamily: FONTS.archivo }}>
        We respect your privacy. Your information will only be used to schedule your consultation.
      </p>
    </form>
  );
}
